
/*
 * *****************************************************************************************
 *
 * 		Copyright (C) 2014-2018 Gowin Semiconductor Technology Co.,Ltd.
 * 		
 * @file		main.c
 * @author		Embedded Development Team
 * @version		V1.0.0
 * @date		2018-5-1 09:00:00
 * @brief		Main program body.
 ******************************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "gw1ns2k.h"
#include <stdio.h>
#include "gw1ns2k_gpio.h"
#include <stdlib.h>
#include <string.h>


//#define DELAY_VALUE		8333000				//25M 1s = 8333000
#define DELAY_VALUE			833300


void Delay(__IO uint32_t nCount)
{
	for(; nCount != 0; nCount--);
}

int main(void)
{
	GPIO0->OUTENSET = 0xffffffff;
	
	while(1)
	{
		GPIO_SetBit(GPIO0, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_0);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0, GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_1);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0, GPIO_Pin_1 | GPIO_Pin_0 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_2);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0,GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_0);
		GPIO_ResetBit(GPIO0, GPIO_Pin_3);
		Delay(DELAY_VALUE);  
	}
}
