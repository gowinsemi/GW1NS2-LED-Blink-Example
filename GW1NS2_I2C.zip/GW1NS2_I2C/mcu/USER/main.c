
/*
 * *****************************************************************************************
 *
 * 		Copyright (C) 2014-2018 Gowin Semiconductor Technology Co.,Ltd.
 * 		
 * @file		main.c
 * @author		Embedded Development Team
 * @version		V1.0.0
 * @date		2018-5-1 09:00:00
 * @brief		Main program body.
 ******************************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "gw1ns2k.h"
#include <stdio.h>
#include "gw1ns2k_gpio.h"
#include "gw1ns2k_uart.h"
#include "gw1ns2k_i2c.h"
#include <stdlib.h>
#include <string.h>

void UartInit(void);

//#define DELAY_VALUE		8333000				//25M 1s = 8333000
#define DELAY_VALUE			833300


void Delay(__IO uint32_t nCount)
{
	for(; nCount != 0; nCount--);
}

int main(void)
{
	GPIO0->OUTENSET = 0xffffffff;
	char uartout[] = "UART Output";
	
	//Init System
	SystemInit();
	//Init Uart
	UartInit();
	//Init I2C
	I2C_Init();

	while(1)
	{
		GPIO_SetBit(GPIO0, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_0);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0, GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_1);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0, GPIO_Pin_1 | GPIO_Pin_0 | GPIO_Pin_3);
		GPIO_ResetBit(GPIO0, GPIO_Pin_2);
		Delay(DELAY_VALUE);
		
		GPIO_SetBit(GPIO0,GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_0);
		GPIO_ResetBit(GPIO0, GPIO_Pin_3);
		Delay(DELAY_VALUE);  

		  /* Start bit */
		  I2C->CONTROL = I2C_CR_SDA | I2C_CR_SCL;
		  I2C->CONTROLC = I2C_CR_SDA;

		  /* Set serial and register address */
		  I2C_SendByte(0x42);
		  unsigned int test = I2C_ReceiveAck();
		  I2C_SendByte(0x1C);
		  test = test + I2C_ReceiveAck();

		//slave address ix 0x42 write and 0x43 for read on ov7675/7670
		char c = I2C_Read(0x1C, 0x42);

		//I2C_Write(uint8_t reg_addr,uint8_t data_byte, 0x42);
	    //c = UART_ReceiveChar(UART0);
	    //UART_SendChar(UART0, c);
		UART_SendChar(UART0, test);//uartout[i]);

	}
}

void UartInit(void)
{
  UART_InitTypeDef UART_InitStruct;

  UART_InitStruct.UART_Mode.UARTMode_Tx = ENABLE;
  UART_InitStruct.UART_Mode.UARTMode_Rx = ENABLE;
  UART_InitStruct.UART_Int.UARTInt_Tx = DISABLE;
  UART_InitStruct.UART_Int.UARTInt_Rx = DISABLE;
  UART_InitStruct.UART_Ovr.UARTOvr_Tx = DISABLE;
  UART_InitStruct.UART_Ovr.UARTOvr_Rx = DISABLE;
  UART_InitStruct.UART_Hstm = DISABLE;
  UART_InitStruct.UART_BaudRate = 115200;//Baud Rate

  UART_Init(UART0,&UART_InitStruct);
}
